# TweakScale Companion :: Rockets :: Known Issues

* The default scale of most engines may not be accurate enough.
	+ It may be revised in the near future, and this can ender existing designs slightly different 
	+ This is *Beta* for a reason! :)
