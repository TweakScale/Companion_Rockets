# TweakScale Companion :: Rockets :: Change Log

* 2023-1005: 0.0.2.0 (LisiasT) for KSP >= 1.2.2
	+ Adds Arc Aerospace, moved from TSCo-Multipass
	+ Updates the Documentation
	+ Implements Issues:
		- [#15](https://github.com/TweakScale/Companion/issues/15) Extend the fix implemented on TweakScaleCompanion_NF#2 to every Companion
* 2020-0806: 0.0.1.0 (LisiasT) for KSP >= 1.2.2
	+ Initial Public Release
	+ Adds support for:
		- Real Engines
